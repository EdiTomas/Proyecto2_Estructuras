/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Reportes;

/**
 *
 * @author edi
 */
public class Reporte1 {
public int codigo;
public String periodo;
public String codigoEdificio;
public String dia;
public int codigoSalon;
public int codigoCurso;
public int codigocatedratico;

    public Reporte1(int codigo, String periodo, String codigoEdificio, String dia, int codigoSalon, int codigoCurso, int codigocatedratico) {
        this.codigo = codigo;
        this.periodo = periodo;
        this.codigoEdificio = codigoEdificio;
        this.dia = dia;
        this.codigoSalon = codigoSalon;
        this.codigoCurso = codigoCurso;
        this.codigocatedratico = codigocatedratico;
    }
 
    
   
    
    
    
}
