/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Usuarios;

/**
 *
 * @author edi
 */
public class NodoDoble {

    private int id ;
    private String nombre;
    private String contraseña;
    private String Tipo; 
    private NodoDoble Siguiente;
    private NodoDoble Anterior; 
    public NodoDoble(int id, String nombre, String contraseña,String Tipo) {
       // this.id = id;
        this.setId(id);
       // this.nombre = nombre;
        this.setNombre(nombre);
       // this.contraseña = contraseña;
        this.setContraseña(contraseña);
       // this.Tipo = Tipo;
        this.setTipo(Tipo);
        this.Siguiente = null;
        this.Anterior = null;
    }

    
    
    
    
    
    
    
    /**
     * @return the id
     */
    public int getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * @return the nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * @param nombre the nombre to set
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * @return the contraseña
     */
    public String getContraseña() {
        return contraseña;
    }

    /**
     * @param contraseña the contraseña to set
     */
    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    /**
     * @return the Siguiente
     */
    public NodoDoble getSiguiente() {
        return Siguiente;
    }

    /**
     * @param Siguiente the Siguiente to set
     */
    public void setSiguiente(NodoDoble Siguiente) {
        this.Siguiente = Siguiente;
    }

    /**
     * @return the Anterior
     */
    public NodoDoble getAnterior() {
        return Anterior;
    }

    /**
     * @param Anterior the Anterior to set
     */
    public void setAnterior(NodoDoble Anterior) {
        this.Anterior = Anterior;
    }

    /**
     * @return the Tipo
     */
    public String getTipo() {
        return Tipo;
    }

    /**
     * @param Tipo the Tipo to set
     */
    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }
     
    
    
}
