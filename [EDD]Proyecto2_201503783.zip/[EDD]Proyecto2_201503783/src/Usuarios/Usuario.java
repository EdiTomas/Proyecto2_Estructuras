/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Usuarios;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author edi
 */
public class Usuario {

    NodoDoble Primero;
    NodoDoble Ultimo;

    public Boolean EstaVacia() {

        return Primero == null && Ultimo == null;
    }

    public void insertarUsuario(int id, String Nombre, String Contraseña, String Tipo) {
        NodoDoble Nuevo = new NodoDoble(id, Nombre, Contraseña, Tipo);
        if (EstaVacia()) {
            Primero = Ultimo = Nuevo;
        } else if (id < Primero.getId()) {
            Nuevo.setSiguiente(Primero);
            Nuevo.setAnterior(null);
            Primero.setAnterior(Nuevo);
            Primero = Nuevo;
        } else if (Ultimo.getId() < id) {
            Ultimo.setSiguiente(Nuevo);
            Nuevo.setAnterior(Ultimo);
            Nuevo.setSiguiente(null);
            Ultimo = Nuevo;
        } else {
            NodoDoble actual = Primero;
            NodoDoble Anterior = Primero;
            while (actual != null) {
                if (Anterior.getId() < id && id < actual.getId()) {
                    break;
                } else {
                    Anterior = actual;
                    actual = actual.getSiguiente();
                }  // fin del else if 
            }
            Anterior.setSiguiente(Nuevo);
            Nuevo.setAnterior(Anterior);
            Nuevo.setSiguiente(actual);
            actual.setAnterior(Nuevo);
        }
    }

    public String RecorrerListaDoble() {

        String Cuerpo = "";

        if (!EstaVacia()) {
            NodoDoble Actual = Primero;
            NodoDoble Anterior = null;
            while (Actual != null) {
               // Cuerpo += "node" + Actual.getId() + "[label = " + "\"{<val> ant |" + Actual.getId() + " \n " + Actual.getNombre() + "|<ptr> sig}\"" + "];\n";
            Cuerpo += "node"+ Actual.getId() + "[" + "label=" + "\"" + "Carnet: " + Actual.getId()+" | Nombre: "+Actual.getNombre()+" | Contraseña :"+Actual.getContraseña()+" | Tipo: "+Actual.getTipo()        +"\""  + ",style =" +"\"" +"rounded,filled"+"\"" + ",width=1.0"+  "]" + ";" + "\n";
     
                Actual = Actual.getSiguiente();
            }
            Actual = Primero;

            while (Actual != null) {
                if (Actual.getAnterior() == null && Actual.getSiguiente() == null) {

                } else if (Actual.getAnterior() == null && Actual.getSiguiente() != null) {
                    Cuerpo += "node" + Actual.getId() + "->" + "node" + Actual.getSiguiente().getId() + ";\n";
                } else if (Actual.getAnterior() != null && Actual.getSiguiente() == null) {
                    Cuerpo += "node" + Actual.getId() + "->" + "node" + Actual.getAnterior().getId() + ";\n";

                } else {

                    Cuerpo += "node" + Actual.getId() + "->" + "node" + Actual.getAnterior().getId() + ";\n";
                    Cuerpo += "node" + Actual.getId() + "->" + "node" + Actual.getSiguiente().getId() + ";\n";
                }
                Actual = Actual.getSiguiente();
            }

        } else {
            System.out.println("La lista Esta Vacia");
        }
        return Cuerpo;
    }

    public Boolean Existe(int id) {
        Boolean existe = false;
        NodoDoble actual = Primero;
        while (actual != null) {
            if (id == actual.getId()) {
                existe = true;
                break;
            }
            actual = actual.getSiguiente();
        }
        return existe;
    }

    public String VerificarContraseña(String Nombre, String Contraseña) {
        String existe = null;
        NodoDoble actual = Primero;
        while (actual != null) {
            if (Nombre.equals(actual.getNombre()) && Contraseña.equals(actual.getContraseña())) {
                existe = actual.getTipo();
                break;
            }
            actual = actual.getSiguiente();
        }
        return existe;
    }

    public void Clear() {
        Primero = Ultimo = null;
    }

    public void Modificar(int id, String Nombre, String Contraseña, String Tipo) {

        NodoDoble Actual = Primero;
        while (Actual != null) {
            if (id == Actual.getId()) {
                Actual.setNombre(Nombre);
                Actual.setContraseña(Contraseña);
                Actual.setTipo(Tipo);
                break;
            }
            Actual = Actual.getSiguiente();
        }

    }

    public NodoDoble Buscar(int id) {

        if (!EstaVacia()) {
            NodoDoble actual;
            
            for (actual = Primero; actual != null; actual = actual.getSiguiente()) {
                if (id == actual.getId()) {
                    return actual;
                }
            }
        } else {
            return null;
        }
        return null;
    }

    public NodoDoble Raiz(){
    return Primero;
    }
    
    
    
    
    
    
    public int Size() {
        int contador = 0;
        if (!EstaVacia()) {
            NodoDoble actual;
            for (actual = Primero; actual != null; actual = actual.getSiguiente()) {
                contador++;
            }
        } else {
            return 0;
        }
        return contador;
    }

    public void Eliminiar(int id) {
        if (!EstaVacia()) {
            NodoDoble Actual = Primero;
            NodoDoble Anterior = null;
            while (Actual != null) {
                if (id == Actual.getId()) {
                    break;
                } else {
                    Anterior = Actual;
                    Actual = Actual.getSiguiente();
                }
            }

            if (Actual != null) {

                if (Primero == Actual && Ultimo == Actual) {
                    System.out.println("id : " + Actual.getId() + " Se ha Eliminado con exito!");
                    Primero = Ultimo = null;
                  //  Primero.setSiguiente(null);
                } else if (Actual == Primero) {
                    System.out.println("id : " + Actual.getId() + "Se ha Eliminado con exito!");
                    // Primero = Primero.getSiguiente();
                    Primero = null;
                    Actual = Actual.getSiguiente();
                    Primero = Actual;
                    Primero.setAnterior(null);
                } else if (Actual == Ultimo) {
                    System.out.println("id : " + Actual.getId() + "Se ha Eliminado con exito!");
                    Anterior.setSiguiente(Ultimo.getSiguiente());

                } else {
                    System.out.println("id : " + Actual.getId() + "Se ha Eliminado con exito!");
                    Anterior.setSiguiente(Actual.getSiguiente());
                    // Actual.setAnterior(Anterior.getAnterior());
                    Actual.getSiguiente().setAnterior(Actual.getAnterior());
//   Actual.setSiguiente(null);
                }
                Actual = null;
            }
        } else {
            System.out.println("La lista esta Vacia");
        }
    }

    public void Graficar() {
        try {
            String ruta = "listadoble.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph G {\n"
                    + "     rankdir=LR; "
                  //  + "" + " node[ shape=record, fontcolor=black, color=coral1];  \n"
                           + "" + " node[ shape=record, fontcolor=black,fillcolor=coral1, style=filled, color=black, width=0.5]  \n" 
          
                            + "edge[color=chartreuse1] \n"
            );
            bw.write(RecorrerListaDoble() + "\n" + "}");

            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "listadoble.png", "listadoble.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "listadoble.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
