/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cursos;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author edi
 */
public class curso {
    
    NodoListaCurso Primero;
    NodoListaCurso Ultimo;

    public Boolean EstaVacio() {
        return Primero == null && Ultimo == null;
    }

    
    public NodoListaCurso Inicio(){
    return Primero;
    }
    
    public int Size(){
        NodoListaCurso indice;
        int contador =0;
        for (indice = Primero; indice != null; indice = indice.getSiguiente()) {
            contador++;
        }
        return contador;
    }
    
    
    
    
    public Boolean buscarLista(int codigo) {
        NodoListaCurso indice;
        Boolean existe = false;
        for (indice = Primero; indice != null; indice = indice.getSiguiente()) {
            if (codigo == indice.getCodigo()) {
                existe = true;
                break;
            }
        }
        return existe;
    }

    
    public NodoListaCurso Find(int codigo) {
        NodoListaCurso indice;
        for (indice = Primero; indice != null; indice = indice.getSiguiente()) {
            if (codigo == indice.getCodigo()) {
               return indice; 
            }
        }
        return null;
    }
    
    
    
    public void InsertarOrden(int codigo,String nombre,int semestre, int creditos) {

        NodoListaCurso nuevo = new NodoListaCurso(codigo,nombre,semestre,creditos);

        if (EstaVacio()) {
            nuevo.setSiguiente(null);
            Primero = Ultimo = nuevo;
        } else if (codigo < Primero.getCodigo()) {
            nuevo.setSiguiente(Primero);
            Primero = nuevo;

        } else {
            NodoListaCurso anterior, p;
            anterior = p = Primero;
            while ((p.getSiguiente() != null) && (codigo > p.getCodigo())) {
                anterior = p;
                p = p.getSiguiente();
            }
            if (codigo > p.getCodigo()) {
                anterior = p;
            }
            nuevo.setSiguiente(anterior.getSiguiente());
            anterior.setSiguiente(nuevo);
        }
    }

    public void Modificar(int codigo,String nombre,int semestre, int creditos){
     NodoListaCurso indice;
        for (indice = Primero; indice != null; indice = indice.getSiguiente()) {
            if (codigo == indice.getCodigo()) {
                  indice.setNombre(nombre);
                  indice.setSemestre(semestre);
                  indice.setCreditos(creditos);
                  
                break;
            }
        }
    }
    
    public void Eliminar(int codigo) {

        if (!EstaVacio()) {
            NodoListaCurso Actual = Primero;
            NodoListaCurso Anterior = null;
            while (Actual != null) {
                if (Actual.getCodigo() == codigo) {
                    break;
                } else {
                    Anterior = Actual;
                    Actual = Actual.getSiguiente();
                }
            }
            if (Actual != null) {
                if (Actual == Primero) {
                    Primero = Primero.getSiguiente();

                } else {
                    Anterior.setSiguiente(Actual.getSiguiente());
                }
                Actual = null;

            }
        } else {
            System.out.println("No existe elementos en La lista");
        }
    }

    public String RecorrerLista() {
        String Cuerpo = "";

        NodoListaCurso Actual = Primero;
        while (Actual != null) {
            if (Primero == Actual) {
                Cuerpo += "nodo"+Primero.getCodigo() + "[" + "label=" + "\"" + "Codigo: " + Primero.getCodigo()+" | Curso: "+Primero.getNombre()+" | Semestre :"+Primero.getSemestre()+" | Creditos: "+Primero.getCreditos()        +"\""  + ",style =" +"\"" +"rounded,filled"+"\"" + ",width=1.0"+  "]" + ";" + "\n";
            } else {
                Cuerpo += "nodo"+ Actual.getCodigo() + "[" + "label=" + "\"" + "Codigo: " + Actual.getCodigo()+" | Curso: "+Actual.getNombre()+" | Semestre :"+Actual.getSemestre()+" | Creditos: "+Actual.getCreditos() +"\"" + ",style =" +"\"" +"rounded,filled"+"\"" + ",width=1.0"+  "]" + ";" + "\n";
            }
            Actual = Actual.getSiguiente();
        }
         Actual = Primero;
        while (Actual != null) {
            if (Primero == Actual) {
                Cuerpo += "nodo"+ Primero.getCodigo() + " ";
            } else {
                Cuerpo += "->" + " " +"nodo"+ Actual.getCodigo();
             }
            Actual = Actual.getSiguiente();
        }
        return Cuerpo;
    }
    
    
    
        public void Graficar() {
        try {
            String ruta = "listacurso.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph curso {\n"
                    + "     rankdir=LR; "
                   // + "" + " node[ shape=record, style=filled,    fillcolor=coral1,  fontcolor=black, color=coral1];  \n"
                   // + "edge[color=chartreuse1] \n"
                    + "" + " node[ shape=record, fontcolor=black,fillcolor=coral1, style=filled, color=black, width=0.5]  \n" + 
                 "    edge[color=chartreuse1] \n" 
            );          
            bw.write(this.RecorrerLista() + "\n" + "}");

            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "listacurso.png", "listacurso.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "listacurso.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
}
    
    
    










    
    
    
    
    
    
    
}
