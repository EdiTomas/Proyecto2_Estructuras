/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cursos;

/**
 *
 * @author edi
 */
public class NodoListaCurso {
    private int codigo;
    private String Nombre;
    private int Semestre;
    private int Creditos;
    private NodoListaCurso Siguiente; 

    public NodoListaCurso(int codigo, String Nombre, int Semestre, int Creditos) {
        this.setCodigo(codigo);
        this.setNombre(Nombre);
        this.setSemestre(Semestre);
        this.setCreditos(Creditos);
        this.setSiguiente(null);
    }
  
    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the Nombre
     */
    public String getNombre() {
        return Nombre;
    }

    /**
     * @param Nombre the Nombre to set
     */
    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    /**
     * @return the Semestre
     */
    public int getSemestre() {
        return Semestre;
    }

    /**
     * @param Semestre the Semestre to set
     */
    public void setSemestre(int Semestre) {
        this.Semestre = Semestre;
    }

    /**
     * @return the Creditos
     */
    public int getCreditos() {
        return Creditos;
    }

    /**
     * @param Creditos the Creditos to set
     */
    public void setCreditos(int Creditos) {
        this.Creditos = Creditos;
    }

    /**
     * @return the Siguiente
     */
    public NodoListaCurso getSiguiente() {
        return Siguiente;
    }

    /**
     * @param Siguiente the Siguiente to set
     */
    public void setSiguiente(NodoListaCurso Siguiente) {
        this.Siguiente = Siguiente;
    }
    
    
    
    
    
    
}
