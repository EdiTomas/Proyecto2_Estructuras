/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolAVL;

/**
 *
 * @author edi
 */
public class NodoABB {
     protected NodoABB izdo;
	 protected NodoABB dcho;
	 protected Object valor;
	 protected String nombre;
         protected String direccion;
         public NodoABB(NodoABB ramaIzdo, Object valor,String nombre,String direccion, NodoABB ramaDcho)
	 {
		 this(valor,nombre,direccion);
                 
		 izdo = ramaIzdo;
		 dcho = ramaDcho;
	 }
         
         public NodoABB(Object valor,String nombre,String direccion)
	 {
             
		 this.valor = valor;
		 this.nombre=nombre;
                 this.direccion= direccion;
                 izdo = dcho = null;
	 }
	 
	 //		 operaciones de acceso
	 public Object valorNodo(){ return valor; }
	 public NodoABB SubArbolIzq(){ return izdo; }
	 public NodoABB SubArbolDer(){ return dcho; }
	 public void nuevoValor(Object d){ valor = d; }
	 public void RamaIzq(NodoABB n){ izdo = n; }
	 public void RamaDer(NodoABB n){ dcho = n; }
}
