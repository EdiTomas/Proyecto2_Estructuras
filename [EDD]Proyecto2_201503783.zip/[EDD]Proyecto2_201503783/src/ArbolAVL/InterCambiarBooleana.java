/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolAVL;

/**
 *
 * @author edi
 */
public class InterCambiarBooleana {
    boolean v;
	 public InterCambiarBooleana (boolean f)
	 {
		 v = f;
	 }
	 public void setLogical(boolean f)
	 {
		 v = f;
	 }
	 public boolean booleanValue()
	 {
		 return v;
	 }
}
