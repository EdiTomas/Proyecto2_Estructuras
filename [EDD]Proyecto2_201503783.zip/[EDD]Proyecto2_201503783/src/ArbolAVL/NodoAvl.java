/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolAVL;

/**
 *
 * @author edi
 */
public class NodoAvl extends NodoABB {

    int fe;

    public NodoAvl(Object valor, String nombre, String direccion) {
        super(valor, nombre, direccion);
        fe = 0;
    }

    public NodoAvl(Object valor, String nombre, String direccion, NodoAvl ramaIzdo, NodoAvl ramaDcho) {
        super(ramaIzdo, valor, nombre, direccion, ramaDcho);
        fe = 0;
    }

}
