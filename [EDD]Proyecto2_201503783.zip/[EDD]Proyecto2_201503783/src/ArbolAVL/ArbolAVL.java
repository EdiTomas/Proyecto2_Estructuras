/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolAVL;

import java.io.BufferedWriter;
import java.io.FileWriter;
import javax.swing.JOptionPane;

/**
 *
 * @author edi
 */
public class ArbolAVL {

    public NodoAvl raiz;

    public ArbolAVL() {
        raiz = null;
    }

    public NodoAvl buscar(int id, NodoAvl r) {
        if (r == null) {
            return null;
        } else if ((int)(r.valor) == id) {
            return r;
        } else if ((int)(r.valor) < id) {
            return buscar(id, (NodoAvl)r.SubArbolDer());
        } else {

            return buscar(id, (NodoAvl)r.SubArbolIzq());
        }
    }
    

public boolean existe(int id, NodoAvl r) {
        if (r == null) {
            return false;
        } else if ((int)(r.valorNodo()) == id) {
            return true;
        }else if ((int)(r.valorNodo()) < id) {
            return existe(id, (NodoAvl)r.SubArbolDer());
        } else {
            return existe(id, (NodoAvl)r.SubArbolIzq());
        }
    }






    
    public void Actualizar(int id,String nombre,String Direccion){

     this.Modificar(id, raiz, nombre, Direccion);
    
}

    public void Modificar(int id, NodoAvl r, String nombre,String Direccion) {
         if (r == null) {
            System.out.println("No existe");
        } else if ((int) (r.valorNodo()) == id) {
            r.nombre = nombre;
            r.direccion=Direccion;
        } else if ((int) (r.valorNodo()) < id) {
         this.Modificar(id, (NodoAvl)r.SubArbolDer(), nombre,Direccion);
        
        } else {
            this.Modificar(id, (NodoAvl)r.SubArbolIzq(), nombre,Direccion);
        }

    }    
    
    
    
    
    private NodoAvl rotacionII(NodoAvl raiz, NodoAvl aux) {
        raiz.RamaIzq(aux.SubArbolDer());
        aux.RamaDer(raiz);
        // actualización de los factores de equilibrio 	
        if (aux.fe == -1) // se cumple en la inserción
        {
            raiz.fe = 0;
            aux.fe = 0;
        } else {
            raiz.fe = -1;
            aux.fe = 1;
        }
        return aux;
    }

    private NodoAvl rotacionDD(NodoAvl raiz, NodoAvl aux) {
        raiz.RamaDer(aux.SubArbolIzq());
        aux.RamaIzq(raiz);
        // actualización de los factores de equilibrio 	
        if (aux.fe == +1) // se cumple en la inserción
        {
            raiz.fe = 0;
            aux.fe = 0;
        } else {
            raiz.fe = +1;
            aux.fe = -1;
        }
        return aux;
    }

    private NodoAvl rotacionID(NodoAvl raiz, NodoAvl aux) {
        NodoAvl n2;

        n2 = (NodoAvl) aux.SubArbolDer();
        raiz.RamaIzq(n2.SubArbolDer());
        n2.RamaDer(raiz);
        aux.RamaDer(n2.SubArbolIzq());

        n2.RamaIzq(aux);
        // actualización de los factores de equilibrio
        if (n2.fe == +1) {
            aux.fe = -1;
        } else {
            aux.fe = 0;
        }
        if (n2.fe == -1) {
            raiz.fe = 1;
        } else {
            raiz.fe = 0;
        }
        n2.fe = 0;
        return n2;
    }

    private NodoAvl rotacionDI(NodoAvl raiz, NodoAvl aux) {
        NodoAvl n2;
        n2 = (NodoAvl) aux.SubArbolIzq();

        raiz.RamaDer(n2.SubArbolIzq());
        n2.RamaIzq(raiz);
        aux.RamaIzq(n2.SubArbolDer());
        n2.RamaDer(aux);
        // actualización de los factores de equilibrio
        if (n2.fe == +1) {
            raiz.fe = -1;
        } else {
            raiz.fe = 0;
        }
        if (n2.fe == -1) {
            aux.fe = 1;
        } else {
            aux.fe = 0;
        }
        n2.fe = 0;
        return n2;
    }

    public void insertar(Object valor,String nombre,String direccion)  {
        InterCambiarBooleana h = new InterCambiarBooleana(false); // intercambia un valor booleano
        raiz = insertarAvl(raiz, valor, h,nombre,direccion);
    }

    private NodoAvl
            insertarAvl(NodoAvl raiz, Object valor, InterCambiarBooleana alto,String nombre,String direccion)  {
        NodoAvl n1;
        if (raiz == null) {
            raiz = new NodoAvl(valor,nombre,direccion);
            alto.setLogical(true);
        } else if ((int)valor<(int)raiz.valorNodo()) {
            NodoAvl iz;
            iz = insertarAvl((NodoAvl) raiz.SubArbolIzq(), valor, alto,nombre,direccion);
            raiz.RamaIzq(iz);
            // regreso por los nodos del camino de búsqueda
            if (alto.booleanValue()) {
                // decrementa el fe por aumentar la altura de rama izquierda
                switch (raiz.fe) {

                    case 1:
                        raiz.fe = 0;
                        alto.setLogical(false);
                        break;

                    case 0:

                        raiz.fe = -1;
                        break;
                    case -1:	// aplicar rotación a la izquierda
                        n1 = (NodoAvl) raiz.SubArbolIzq();
                        if (n1.fe == -1) {
                            raiz = rotacionII(raiz, n1);
                        } else {
                            raiz = rotacionID(raiz, n1);
                        }
                        alto.setLogical(false);
                }
            }
        } else if ((int)valor>(int)raiz.valorNodo()) {
            NodoAvl dr;
            dr = insertarAvl((NodoAvl) raiz.SubArbolDer(), valor, alto,nombre,direccion);
            raiz.RamaDer(dr);
            // regreso por los nodos del camino de búsqueda
            if (alto.booleanValue()) {
                // incrementa el fe por aumentar la altura de rama izquierda
                switch (raiz.fe) {

                    case 1:		 // aplicar rotación a la derecha
                        n1 = (NodoAvl) raiz.SubArbolDer();
                        if (n1.fe == +1) {
                            raiz = rotacionDD(raiz, n1);
                        } else {
                            raiz = rotacionDI(raiz, n1);
                        }
                        alto.setLogical(false);
                        break;

                    case 0:
                        raiz.fe = +1;
                        break;

                    case -1:
                        raiz.fe = 0;
                        alto.setLogical(false);
                }
            }
        } else {
          //  throw new Exception("No puede haber claves repetidas ");
            System.out.println("No puede haber claves repetidas ");
       //  JOptionPane.showMessageDialog(null, "No puede haber claves repetidas ");
        }
        return raiz;
    }

            
    public void eliminar(Object valor)  {
        InterCambiarBooleana flag = new InterCambiarBooleana(false);
        raiz = borrarAvl(raiz, valor, flag);
    }

    private NodoAvl borrarAvl(NodoAvl r, Object clave, InterCambiarBooleana cambiaAltura)  {
        if (r == null) {
           // throw new Exception(" Nodo no encontrado ");
            return null;
        } else if ((int)clave<(int)(r.valorNodo())) {
            NodoAvl iz;
            iz = borrarAvl((NodoAvl) r.SubArbolIzq(), clave, cambiaAltura);
            r.RamaIzq(iz);
            if (cambiaAltura.booleanValue()) {
                r = equilibrar1(r, cambiaAltura);
            }
        } else if ((int)clave>(int)(r.valorNodo())) {
            NodoAvl dr;
            dr = borrarAvl((NodoAvl) r.SubArbolDer(), clave, cambiaAltura);
            r.RamaDer(dr);
            if (cambiaAltura.booleanValue()) {
                r = equilibrar2(r, cambiaAltura);
            }
        } else // Nodo encontrado
        {
            NodoAvl q;

            q = r; 	 // nodo a quitar del árbol
            if (q.SubArbolIzq() == null) {
                r = (NodoAvl) q.SubArbolDer();
                cambiaAltura.setLogical(true);
            } else if (q.SubArbolDer() == null) {
                r = (NodoAvl) q.SubArbolIzq();
                cambiaAltura.setLogical(true);
            } else { 			 // tiene rama izquierda y derecha
                NodoAvl iz;
                iz = reemplazar(r, (NodoAvl) r.SubArbolIzq(), cambiaAltura);
                r.RamaIzq(iz);
                if (cambiaAltura.booleanValue()) {
                    r = equilibrar1(r, cambiaAltura);
                }
            }
            q = null;
         //   q.nombre=null;
          //  q.direccion=null;
        }
        return r;
    }

    private NodoAvl reemplazar(NodoAvl n, NodoAvl act, InterCambiarBooleana cambiaAltura) {
        if (act.SubArbolDer() != null) {
            NodoAvl d;
            d = reemplazar(n, (NodoAvl) act.SubArbolDer(), cambiaAltura);
            act.RamaDer(d);
            if (cambiaAltura.booleanValue()) {
                act = equilibrar2(act, cambiaAltura);
            }
        } else {
            n.nuevoValor(act.valorNodo());
            n.nombre=act.nombre;
            n.direccion=act.direccion;
            n = act;
            act = (NodoAvl) act.SubArbolIzq();
            n = null;
            cambiaAltura.setLogical(true);
        }
        return act;
    }

    private NodoAvl equilibrar1(NodoAvl n, InterCambiarBooleana cambiaAltura) {
        NodoAvl n1;
        switch (n.fe) {
            case -1:
                n.fe = 0;
                break;
            case 0:
                n.fe = 1;
                cambiaAltura.setLogical(false);
                break;
            case +1: 	//se aplicar un tipo de rotación derecha
                n1 = (NodoAvl) n.SubArbolDer();
                if (n1.fe >= 0) {
                    if (n1.fe == 0) //la altura no vuelve a disminuir
                    {
                        cambiaAltura.setLogical(false);
                    }
                    n = rotacionDD(n, n1);
                } else {
                    n = rotacionDI(n, n1);
                }
                break;
        }
        return n;
    }

    private NodoAvl equilibrar2(NodoAvl n, InterCambiarBooleana cambiaAltura) {
        NodoAvl n1;
        switch (n.fe) {
            case -1:	// Se aplica un tipo de rotación izquierda
                n1 = (NodoAvl) n.SubArbolIzq();
                if (n1.fe <= 0) {
                    if (n1.fe == 0) {
                        cambiaAltura.setLogical(false);
                    }
                    n = rotacionII(n, n1);
                } else {
                    n = rotacionID(n, n1);
                }
                break;
            case 0:
                n.fe = -1;
                cambiaAltura.setLogical(false);
                break;
            case +1:
                n.fe = 0;
                break;

        }
        return n;
    }


public void mostraArbolAvl(){
    
    this.GraficarArbolBB(raiz);
    }
    
    
    
      public void GraficarArbolBB(NodoAvl raiz){
        try {
            String ruta = "ArbolAvl.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph G {\n"
                    + "     rankdir=TB; "
                    + "" + " node[ shape=record,  style=filled ,fillcolor=seashell2, fontcolor=black, color=coral1];  \n"
                    + "edge[color=chartreuse1] \n"
                         //   + "edge[color=chartreuse1] \n"
            
            );
       //  bw.write(this.RecorrerArbol(raiz) );
            bw.write(this.recorrer(raiz) + "\n" + "}");
                 cuerpo = "";
            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "ArbolAvl.png", "ArbolAvl.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "ArbolAvl.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    
    
    }
    
    
   String cuerpo="";
    public String recorrer(NodoAvl raiz){
      if(raiz !=null){
        cuerpo += "node" + raiz.valor+ "[label = " + "\"<val>|"   +raiz.valor +":  "+ raiz.nombre+" "+raiz.direccion + "|<ptr>\"" + "];\n";
        if (raiz.SubArbolIzq() != null)
          {
            cuerpo +=  "node"+raiz.valor+ ":val->"+"node"+raiz.SubArbolIzq().valor+"\n" ;
       }
       recorrer((NodoAvl)raiz.SubArbolIzq());
       if (raiz.SubArbolDer() != null)
       {
       cuerpo +=  "node"+raiz.valor+":ptr->"+ "node"+raiz.SubArbolDer().valor+"\n" ;
       }
       
      recorrer((NodoAvl)raiz.SubArbolDer());
     
      }
      return cuerpo;
  }

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
