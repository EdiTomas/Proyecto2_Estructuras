/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edd.proyecto2_201503783;

import Aplicacion.Login;
import ArbolAVL.ArbolAVL;
import ArbolB.ArbolBHorarios;
import ArbolB.Horarios;
import Asignaciones.Asignar;
import Cursos.curso;
import EdificioYSalones.Edificio;
import EdificioYSalones.NodoListaCircular;
import EdificioYSalones.Salon;
import TablaHash.TablaDispersa;
import Usuarios.Usuario;

/**
 *
 * @author edi
 */
public class EDDProyecto2_201503783 {

    /**
     * @param args the command line arguments
     */
    
    public static Asignar as = new Asignar();
    public static ArbolBHorarios ab = new ArbolBHorarios();
    public static TablaDispersa tb = new TablaDispersa();
    public static  ArbolAVL avl = new ArbolAVL();
    public static  curso c = new curso();
    public static  Edificio ed = new Edificio();
    public static  Usuario user  = new Usuario();
    public static  Login lg = new Login();
       
    
    public static void main(String[] args)  {
  
         lg.show();
         System.out.println("Hola mundo");
        /*
        Asignar as = new Asignar();
        as.Insertar(201503783, 777, 65, 23);
        as.Insertar(201504555, 770, 25, 25);
        as.Graficar();
        */
        
        
       /*
        ArbolBHorarios ab = new ArbolBHorarios();
       
        //int codigo, String periodo, String codigoEdificio, String dia, int codigoSalon, int codigoCurso, int codigocatedratico
        ab.insertar(new Horarios(5,"lsls","t4",1,1,"a",3));
        //ab.insertar(new Horarios(1,"hola","t1",4,1,"a",3));
        ab.insertar(new Horarios(2,"aa","t2",4,1,"a",3));
       // ab.insertar(new Horarios(3,"bb","t3",4,1,"b",3));
        ab.insertar(new Horarios(4,"mmsms","t3",4,1,"v",3));
        ab.insertar(new Horarios(6,"mmsms","t3",4,1,"v",3));
        ab.insertar(new Horarios(8,"mmsms","t3",4,1,"v",3));
       
        if(ab.Existe(0)){
           System.out.println("Uno");
       
       } 
        
         for(int i =0;i< 5;i++){
        System.out.println(""+ab.RetornarPagina(5).Calendario[1].getCodigoEdificio());
        System.out.println(""+ab.RetornarPagina(5).Calendario[1].getCodigoCurso());
        
         }   
        
        
        ab.Graficar();
        
        */
        
       // tabla dispersa ************************************* 
   //    TablaDispersa tb = new TablaDispersa();
       // tb.insertar("201503608","Juan Luis Robles","luisrobles2408@gmail.com");
        /*
        tb.insertar("201503689","Oscar Amilcar Velas","kokah96@gmail.com");
        tb.insertar("201603783","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503000","shshshshs","sjjsjs");
       tb.insertar("201503001","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503002","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503003","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503004","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503005","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503777","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503778","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503779","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503780","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503781","Morgan Gordan","morgan3320141@gmail.com");
       tb.insertar("201503783","Edi Yovani Tomas Reynoso","tomas3320141@gmail.com");
        tb.insertar("201703783","sjsjs","tomas3320141@gmail.com");
        tb.insertar("201803783","bbbbbbb","tomas3320141@gmail.com");
        tb.insertar("201903783","rasin op","tomas3320141@gmail.com");
        tb.insertar("201303783","tigre op","tomas3320141@gmail.com");
        tb.insertar("201278945","leon op","tomas3320141@gmail.com");
        tb.insertar("200078945","fiera","tomas3320141@gmail.com");
        tb.insertar("200145678","Guerra","tomas3320141@gmail.com");
      */
        
        
       //tb.insertar("201503783","Edi Yovani Tomas Reynoso","tomas3320141@gmail.com");
      /*
        tb.eliminar("201503608");
        tb.eliminar("201503689");
        tb.eliminar("201603783");
        tb.eliminar("201503000");
        tb.eliminar("201503001");
        tb.eliminar("201503002");
        tb.eliminar("201503003");
        tb.eliminar("201503004");
        tb.eliminar("201503005");
        tb.eliminar("201503777");
        tb.eliminar("201503778");
        tb.eliminar("201503779");
        tb.eliminar("201503780");
        tb.eliminar("201503781");
        tb.eliminar("201503783");
        // tb.modificar("201603783", "Pepa", "mmmmm");
        */
      //  tb.eliminar("14");
        //     tb.GraficarTablaHash();
        
      
             
             
        /*
        ArbolAVL avl = new ArbolAVL();
        avl.insertar(Integer.parseInt("1"), "a", "jl");
        avl.insertar(2, "b", "cs");
        avl.insertar(4, "c", "aa");
        avl.insertar(6, "d", "bb");
        avl.insertar(7, "e", "sd");
        avl.insertar(3, "f", "sms");
        
        
        avl.Actualizar(7, "Maria", "ksksks");
        avl.Actualizar(3, "Volver", "ksksks");
        
        avl.eliminar(4);
       // avl.eliminar(3);
       // avl.eliminar(1);
        
       // avl.eliminar(6);
        avl.mostraArbolAvl();
        */
        
        
        
        
        
        
        
        
        
        
        /*
        curso c = new curso();
         c.InsertarOrden(002, "Fisica", "Primero", 8);
         c.InsertarOrden(150, "Intermedia", "Cuarto", 8);
         c.InsertarOrden(001, "Matematica", "Primero", 10);
         c.Modificar(150, "Estadistica", "Segundo", 6);
         // c.Eliminar(1);
         // c.Eliminar(2);
         // c.Eliminar(150);
          c.Graficar();
        */
        

         //Edificio ed = new Edificio();
         
         
         /*
         Salon s = new Salon();
         s.InsertarOrden(1, 20);
         s.InsertarOrden(2, 30);
         s.InsertarOrden(3, 15);
         
         Salon s1 = new Salon();
         s1.InsertarOrden(1, 20);
         s1.InsertarOrden(2, 30);
         s1.InsertarOrden(3, 15);
         
         Salon s2 = new Salon();
         s2.InsertarOrden(12, 20);
         s2.InsertarOrden(8, 30);
         s2.InsertarOrden(9, 15);
         */  
         
        // s2.Eliminar(9);
        
        
      //   ed.insertarListaDobleCircular("T1");
        // ed.insertarListaDobleCircular("T4");
         
        // ed.insertarListaDobleCircular("T2");
        // ed.insertarListaDobleCircular("T3");
         
        // ed.buscar("T1").getListaSalon().InsertarOrden(1, 0);
        // ed.buscar("T1").getListaSalon().InsertarOrden(2, 100);
        // ed.buscar("T2").getListaSalon().InsertarOrden(2, 100);
         
         
         
         //ed.Eliminiar("T1");
        // ed.buscar("T1").getListaSalon().Eliminar(1);
          //       ed.GraficarListaDoblementeCircular();
        
        
        
        
        
        
        /*
        Usuario u  = new Usuario();
        u.insertarUsuario(4, "ndndnnd", "trtrtrtrt","Colaborador");
        u.insertarUsuario(5, "distancia", "tksksks","Colaborador");
        u.insertarUsuario(1, "kvkvkvkvkvk", "jsjsjs","Estudiante");
        u.insertarUsuario(2, "msmsmsmsms", "shhshshs","Colaborador");
        u.insertarUsuario(3, "psosoos", "shhshshs","Colaborador");
        u.Modificar(1, "perfecto", "Es una noña","Colaborador");
        u.Modificar(5, "visis", "Es una noña","Colaborador");
        u.Eliminiar(-1);
        u.Graficar();
         */
    
    
        
        
        
        
        
        
        
    
    
    
    
    
    
    
    
    }
    
}
