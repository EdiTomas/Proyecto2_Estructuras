/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Asignaciones;

import Usuarios.NodoDoble;
import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author edi
 */
public class Asignar {

    NodoListaAsignaciones Primero;
    NodoListaAsignaciones Ultimo;

    public Boolean EstaVacio() {
        return Primero == null && Ultimo == null;
    }

    public int Size() {
        int contador = 0;
        if (!EstaVacio()) {
            NodoListaAsignaciones actual;
            for (actual = Primero; actual != null; actual = actual.getSiguiente()) {
                contador++;
            }
        } else {
            return 0;
        }
        return contador;
    }
    
    public NodoListaAsignaciones Inicio(){
      return Primero;
    }
    
    
    public Boolean buscarLista(int codigo) {
        NodoListaAsignaciones indice;
        Boolean existe = false;
        for (indice = Primero; indice != null; indice = indice.getSiguiente()) {
            if (codigo == indice.getCarnet()) {
                existe = true;
                break;
            }
        }
        return existe;
    }

    public void Insertar(int carnet, int codigocurso, int zona, int Final) {

        NodoListaAsignaciones nuevo = new NodoListaAsignaciones(carnet, codigocurso, zona, Final);
        if (EstaVacio()) {
            Primero = Ultimo = nuevo;
        } else {
            nuevo.setSiguiente(Primero);
            Primero = nuevo;
        }
    }

    //int carnet, int codigocurso, int zona, int Final
    public void Modificar(int carnet, int codigocurso, int zona, int Final) {
        NodoListaAsignaciones indice;
        for (indice = Primero; indice != null; indice = indice.getSiguiente()) {
            if (carnet == indice.getCarnet()) {
                indice.setCodigoHorario(codigocurso);
                indice.setZona(zona);
                indice.setFinal(Final);
                break;
            }
        }
    }

    public void Eliminar(int carnet) {

        if (!EstaVacio()) {
            NodoListaAsignaciones Actual = Primero;
            NodoListaAsignaciones Anterior = null;
            while (Actual != null) {
                if (Actual.getCarnet() == carnet) {
                    break;
                } else {
                    Anterior = Actual;
                    Actual = Actual.getSiguiente();
                }
            }
            if (Actual != null) {
                if (Actual == Primero) {
                    Primero = Primero.getSiguiente();

                } else {
                    Anterior.setSiguiente(Actual.getSiguiente());
                }
                Actual = null;
            }
        } else {
            System.out.println("No existe elementos en La lista");
        }
    }



public String RecorrerLista() {
        String Cuerpo = "";

        NodoListaAsignaciones Actual = Primero;
        while (Actual != null) {
            if (Primero == Actual) {
                Cuerpo += "nodo"+Primero.getCarnet() + "[" + "label=" + "\"" + "Carnet : " + Primero.getCarnet()+" | Curso: "+Primero.getCodigoHorario()+" | Zona :"+Primero.getZona()+" | Final : "+Primero.getFinal()        +"\""  + ",style =" +"\"" +"rounded,filled"+"\"" + ",width=1.0"+  "]" + ";" + "\n";
            } else {
                Cuerpo += "nodo"+ Actual.getCarnet() + "[" + "label=" + "\"" + "Carnet : " + Actual.getCarnet()+" | Curso: "+Actual.getCodigoHorario()+" | Zona :"+Actual.getZona()+" | Final : "+Actual.getFinal() +"\"" + ",style =" +"\"" +"rounded,filled"+"\"" + ",width=1.0"+  "]" + ";" + "\n";
            }
            Actual = Actual.getSiguiente();
        }
         Actual = Primero;
        while (Actual != null) {
            if (Primero == Actual) {
                Cuerpo += "nodo"+ Primero.getCarnet() + " ";
            } else {
                Cuerpo += "->" + " " +"nodo"+ Actual.getCarnet();
             }
            Actual = Actual.getSiguiente();
        }
        return Cuerpo;
    }
    
    
    
        public void Graficar() {
        try {
            String ruta = "listaAsignaciones.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph curso {\n"
                    + "     rankdir=LR; "
                   // + "" + " node[ shape=record, style=filled,    fillcolor=coral1,  fontcolor=black, color=coral1];  \n"
                   // + "edge[color=chartreuse1] \n"
                    + "" + " node[ shape=record, fontcolor=black,fillcolor=coral1, style=filled, color=black, width=0.5]  \n" + 
                 "    edge[color=chartreuse1] \n" 
            );          
            bw.write(this.RecorrerLista() + "\n" + "}");

            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "listaAsignaciones.png", "listaAsignaciones.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "listaAsignaciones.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

        } catch (Exception e) {
            e.printStackTrace();
        }
}





















}
