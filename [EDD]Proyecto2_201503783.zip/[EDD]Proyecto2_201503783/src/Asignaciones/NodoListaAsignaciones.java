/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Asignaciones;

/**
 *
 * @author edi
 */
public class NodoListaAsignaciones {
    private int carnet;
    private int codigoHorario;
    private int zona;
    private int Final;
    private NodoListaAsignaciones siguiente;
    
    
    public NodoListaAsignaciones(int carnet, int codigoHorario, int zona, int Final) {
        this.carnet = carnet;
        this.codigoHorario = codigoHorario;
        this.zona = zona;
        this.Final = Final;
    }

    /**
     * @return the carnet
     */
    public int getCarnet() {
        return carnet;
    }

    /**
     * @param carnet the carnet to set
     */
    public void setCarnet(int carnet) {
        this.carnet = carnet;
    }

    /**
     * @return the codigocurso
     */
    public int getCodigoHorario() {
        return codigoHorario;
    }

    /**
     * @param codigocurso the codigocurso to set
     */
    public void setCodigoHorario(int codigocurso) {
        this.codigoHorario = codigocurso;
    }

    /**
     * @return the zona
     */
    public int getZona() {
        return zona;
    }

    /**
     * @param zona the zona to set
     */
    public void setZona(int zona) {
        this.zona = zona;
    }

    /**
     * @return the Final
     */
    public int getFinal() {
        return Final;
    }

    /**
     * @param Final the Final to set
     */
    public void setFinal(int Final) {
        this.Final = Final;
    }

    /**
     * @return the siguiente
     */
    public NodoListaAsignaciones getSiguiente() {
        return siguiente;
    }

    /**
     * @param siguiente the siguiente to set
     */
    public void setSiguiente(NodoListaAsignaciones siguiente) {
        this.siguiente = siguiente;
    }
   
     
    
    
    
    
}
