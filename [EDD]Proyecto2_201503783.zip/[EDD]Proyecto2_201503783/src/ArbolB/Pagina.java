/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolB;

import Reportes.Reporte1;
import java.util.ArrayList;

/**
 *
 * @author edi
 */
public class Pagina {
 Pagina ramas[];
   public Horarios[] Calendario;
    private int contador;
     public  ArrayList<Reporte1> reporte = new ArrayList();  
 
    
    Pagina(){
        ramas=new Pagina[5];
        Calendario=new Horarios[5];
        contador=0;
        for(int i=0;i<5;i++){
            ramas[i]=null;
            Calendario[i]=null;
        }
    }
    
    public String getDotName(){
        return "Nodo"+this.hashCode();
    }
    
    
    
    
    public void  RecorrerLista(){
    
        for( int i = 0; i < 5; i++ ) {
            if(Calendario[i]!=null){
            Reporte1 rep = new Reporte1(
            Calendario[i].getCodigo(),
            Calendario[i].getPeriodo(),
            Calendario[i].getCodigoEdificio(),
            Calendario[i].getDia(),
            Calendario[i].getCodigoSalon(),
            Calendario[i].getCodigoCurso(),
            Calendario[i].getCodigocatedratico());
            reporte.add(rep);
        
            }
        }
        for( int i = 0; i < 5; i++ ) {
            if(ramas[i]!=null ){
                ramas[i].RecorrerLista();
            }
        }
    }
    
    
    
    
    
    
    
   
    public String obtenerDot(){
    StringBuilder b = new StringBuilder();
        
        b.append(getDotName());
        b.append("[label=\"<P0>");
        for( int i = 0; i < 5; i++ ) {
            if(Calendario[i]!=null){
                b.append("|" +"Codigo: "+Calendario[i].getCodigo()+", Periodo: "+Calendario[i].getPeriodo()
                        +",Dia: "+Calendario[i].getDia() +"Curso: "+  Calendario[i].getCodigoCurso()   
                        +"Salon: "+  Calendario[i].getCodigoSalon()+"Edificio: "+ Calendario[i].getCodigoEdificio()
                        +"Catedratico: "+ Calendario[i].getCodigocatedratico()
                );
                b.append( "|<P" + (i) + ">" );                
            }
        }
        
        b.append(                   "\"];\n");
        
        for( int i = 0; i < 5 ; i++ ) {
            if( ramas[i] != null )   {
                b.append( ramas[i].obtenerDot() );
                b.append( getDotName() + ":P" + i + " -> " + ramas[i].getDotName() + ";\n" );
            }
        }
        
        return b.toString();
    
    }
    
    
    
    
    
    
    
    
    
    public boolean estaLleno(){
        return contador==4;
    }
    
    public boolean estaSemiLLeno(){
        return (contador<5/2);
    }
    
    public int getContador(){
        return contador;
    }
    public void  setContador(int contador){
        this.contador=contador;
    }   
}
