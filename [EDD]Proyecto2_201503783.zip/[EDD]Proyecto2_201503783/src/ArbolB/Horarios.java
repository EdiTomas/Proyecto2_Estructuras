/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolB;

/**
 *
 * @author edi
 */
public class Horarios {

private int codigo;
private String periodo;
private String codigoEdificio;
private String dia;
private int codigoSalon;
private int codigoCurso;
private int codigocatedratico;

    public Horarios() {
    
    
    
    }

public Horarios(int codigo, String periodo,String dia,  
         int codigoCurso,int codigoSalon,String codigoEdificio, int codigocatedratico) {
       
    this.codigo = codigo;
        this.periodo = periodo;
        this.dia = dia;
        this.codigoCurso = codigoCurso;
        this.codigoSalon = codigoSalon;
        this.codigoEdificio = codigoEdificio;
        this.codigocatedratico = codigocatedratico;
    }


 
/*
public void aumentarEjemplares(){
        this.ejemplares++;
    }
   
    public void aumentarPrestados(){
        this.numeroPrestados++;
    }

*/

    /**
     * @return the codigo
     */
    public int getCodigo() {
        return codigo;
    }

    /**
     * @param codigo the codigo to set
     */
    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    /**
     * @return the periodo
     */
    public String getPeriodo() {
        return periodo;
    }

    /**
     * @param periodo the periodo to set
     */
    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    /**
     * @return the codigoEdificio
     */
    public String getCodigoEdificio() {
        return codigoEdificio;
    }

    /**
     * @param codigoEdificio the codigoEdificio to set
     */
    public void setCodigoEdificio(String codigoEdificio) {
        this.codigoEdificio = codigoEdificio;
    }

    /**
     * @return the dia
     */
    public String getDia() {
        return dia;
    }

    /**
     * @param dia the dia to set
     */
    public void setDia(String dia) {
        this.dia = dia;
    }

    /**
     * @return the codigoSalon
     */
    public int getCodigoSalon() {
        return codigoSalon;
    }

    /**
     * @param codigoSalon the codigoSalon to set
     */
    public void setCodigoSalon(int codigoSalon) {
        this.codigoSalon = codigoSalon;
    }

    /**
     * @return the codigoCurso
     */
    public int getCodigoCurso() {
        return codigoCurso;
    }

    /**
     * @param codigoCurso the codigoCurso to set
     */
    public void setCodigoCurso(int codigoCurso) {
        this.codigoCurso = codigoCurso;
    }

    /**
     * @return the codigocatedratico
     */
    public int getCodigocatedratico() {
        return codigocatedratico;
    }

    /**
     * @param codigocatedratico the codigocatedratico to set
     */
    public void setCodigocatedratico(int codigocatedratico) {
        this.codigocatedratico = codigocatedratico;
    }




    
}
