/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolB;

import Reportes.Reporte1;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.*;
/**
 *
 * @author edi
 */
public class ArbolBHorarios {
    
    
    
public Pagina raiz;
    
    public ArbolBHorarios(){
        raiz=null;
        
    }
    
    public void insertar(Horarios hr){
        raiz=insertarRecursivo(raiz,hr);
      //  raiz.RecorrerLista();
    }
    
    public void RecorrerListas(){
      raiz.RecorrerLista();
    }
    
    public void Graficar(){
    
             try {
            String ruta = "ArbolB5.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph G {\n"
                    //+ "     rankdir=LR; "
                    + "" + " node[ shape=record,  style=filled ,fillcolor=seashell2, fontcolor=black, color=coral1];  \n"
                            
                //    + "" + " node[ shape=record, fontcolor=black, color=coral1         ];  \n"
                //    + " node [shape=record];\n "
                       + "edge[color=chartreuse1] \n"
            );
            bw.write(raiz.obtenerDot() + "\n" + "}");

            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tjpg", "-o", "ArbolB5.jpg", "ArbolB5.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "ArbolB5.jpg");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

        } catch (Exception e) {
            e.printStackTrace();
        }

   
        
    }
    
    
    /*
    public void verdot() {
        String toprint="digraph g { \n node [shape=record];\n ";
        
        toprint+=raiz.obtenerDot();
        toprint+="}";
        
        
            FileWriter f;
        try {
            f = new FileWriter( "arbolB5.dot");
            f.write(toprint);

            f.close();

        } catch (IOException ex) {
            Logger.getLogger(arbolB5.class.getName()).log(Level.SEVERE, null, ex);
        }
        try{
            Runtime rt=Runtime.getRuntime();
            rt.exec("dot -Tpng arbolB5.dot -o arbolB5.png");
            //Desktop.getDesktop().open(new File("arbolB.png"));
        }catch(Exception e){}
            
    }
    */
    
    private Pagina insertarRecursivo(Pagina Actual,Horarios hr){
        boolean subir;
        ContenedorHorario contmedio=new ContenedorHorario();
        ContenedorPagina contnd=new ContenedorPagina();
        subir=EmpujarHaciaArriba(Actual,hr,contmedio,contnd);
        
        if(subir){
            Pagina page;
            page=new Pagina();
            page.setContador(1);
            page.Calendario[1]=contmedio.medio;
            page.ramas[0]=Actual;
            page.ramas[1]=contnd.nd;
            Actual=page;
        }
        return Actual;
    }
    
    private boolean EmpujarHaciaArriba(Pagina ra,Horarios hr,ContenedorHorario contmedio,ContenedorPagina contnd){
        Contenedorint k=new Contenedorint();
        boolean goUp=false;
        if(ra==null){
            goUp=true;
            contmedio.medio=hr;
            contnd.nd=null;
        }else{
            boolean esta;
            esta=buscarEnNodo(ra, hr.getCodigo(),k);
            if(esta){
               // ra.Calendario[k.numero];
                return false;
            }
            
            goUp=EmpujarHaciaArriba(ra.ramas[k.numero],hr,contmedio,contnd);
            if(goUp )
                if(ra.estaLleno())
                    partirNodo(ra,contmedio,contnd,k.numero);
            else{
                goUp=false;
                insertarEnPagina(ra,contmedio.medio,contnd.nd,k.numero);
            }
        }
        return goUp;
    }
    
 //**********************************Buscar  un booleano************************************************   
    public boolean Existe(int clave){
     Contenedorint k=new Contenedorint();
      return  find(raiz,clave,k);     
    }
    
    public boolean find(Pagina actual,int clave,Contenedorint indice){
        if(actual ==null){
            return false;
        }else{
           boolean esta ;
           esta = buscarEnNodo(actual,clave,indice);
            if(esta){
            return true;
            }else{
               return find(actual.ramas[indice.numero],clave,indice);
            }
        }
    }   
    
   //*********************************Devuelve el Nodo************************************************** 
     
    public Pagina RetornarPagina(int clave){
     Contenedorint k=new Contenedorint();
        return BuscarPagina(raiz,clave,k);
    }
    
    
    
   public Pagina BuscarPagina(Pagina actual,int clave,Contenedorint indice){
        if(actual ==null){
            return null;
        }else{
           boolean esta ;
           esta = buscarEnNodo(actual,clave,indice);
            if(esta){
            return actual;
            }else{
               return BuscarPagina(actual.ramas[indice.numero],clave,indice);
            }
        }
   
   
   } 
    
    ///**********************************************************************
    private boolean buscarEnNodo(Pagina ra,int clave,Contenedorint k){
        int index;
        boolean encontrado;
        if(clave<ra.Calendario[1].getCodigo()){
            encontrado=false;
            index=0;
        }else{
           index=ra.getContador();
           while(clave<ra.Calendario[index].getCodigo()&& index>1)
               index--;
               encontrado=(clave==ra.Calendario[index].getCodigo());
               
               
        }
        k.numero=index;
        return encontrado;
    }
    
    
    private void partirNodo(Pagina ra, ContenedorHorario contmedio, ContenedorPagina contnd,int kk) {
    
        int i, posMdna, k;
        Pagina nuevaPag;
        k = kk;
        
        posMdna = (k <= 5/2) ? (5/2) : (5/2 + 1);
        nuevaPag = new Pagina();
        for (i = posMdna + 1; i < 5; i++){
            nuevaPag.Calendario[i - posMdna]= ra.Calendario[i];
            nuevaPag.ramas[i - posMdna]=ra.ramas[i];
        }
        
        nuevaPag.setContador(4 - posMdna); 
        ra.setContador(posMdna); 
        
        if (k <= 5/2){
            insertarEnPagina(ra, contmedio.medio,contnd.nd,kk); 
            
        }
        else{
            kk = k - posMdna;
            insertarEnPagina(nuevaPag, contmedio.medio, contnd.nd,kk);
            
        }
        
        contmedio.medio = ra.Calendario[ra.getContador()];
    
        nuevaPag.ramas[0]= ra.ramas[ra.getContador()];
        ra.setContador(ra.getContador()-1); // se quita la mediana
        contnd.nd = nuevaPag; // devuelve la nueva Página
        if (!(k <= 5/2) ||(k <= 5/2)){
            ra.Calendario[3]=null;
            ra.Calendario[4]=null;
            ra.ramas[3]=null;
            ra.ramas[4]=null;
        }
    }
    
    private void insertarEnPagina(Pagina ra, Horarios contmedio, Pagina contnd,int k) {
        for(int i=ra.getContador();i>=(k+1);i--){
            ra.Calendario[i+1]=ra.Calendario[i];
            ra.ramas[i+1]=ra.ramas[i];
        }
        ra.Calendario[k+1]=contmedio;
        ra.ramas[k+1]=contnd;
        ra.setContador((ra.getContador()+1));
    }
    
    
    
    
    
    /*
    public void aumentarPrestados(int clave){
        aumentarPrestados(raiz,clave);
    }
    */
    
  /*  
    private void aumentarPrestados(Pagina ra,int clave){
        Contenedorint kk=new Contenedorint();
        if(ra==null)
            return;
        else{
            if(buscarEnNodo(ra, clave,kk))
                ra.Calendario[kk.numero].aumentarPrestados();
            else aumentarPrestados(ra.ramas[kk.numero],clave);
        }
    }
*/
    



}

class ContenedorPagina{
    Pagina nd;
    ContenedorPagina(){
        nd=null;
    }
}

class ContenedorHorario{
    Horarios medio;
    ContenedorHorario(){
        medio=null;
    }
}

class Contenedorint{
    int numero;
    
}


/*
 class Pagina{
        
}*/