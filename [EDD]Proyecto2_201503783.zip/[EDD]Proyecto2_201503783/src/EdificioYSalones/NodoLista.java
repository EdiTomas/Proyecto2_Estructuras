/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EdificioYSalones;

/**
 *
 * @author edi
 */
public class NodoLista {
  
    private int numerosalon;
    private int Capacidad;
    private NodoLista Siguiente; 
    
    public NodoLista(int numerosalon, int Capacidad) {
        //this.numerosalon = numerosalon;
        //this.Capacidad = Capacidad;
        this.setNumerosalon(numerosalon);
        this.setCapacidad(Capacidad);
    
    }

    
    
    
     
    /**
     * @return the numerosalon
     */
    public int getNumerosalon() {
        return numerosalon;
    }

    /**
     * @param numerosalon the numerosalon to set
     */
    public void setNumerosalon(int numerosalon) {
        this.numerosalon = numerosalon;
    }

    /**
     * @return the Capacidad
     */
    public int getCapacidad() {
        return Capacidad;
    }

    /**
     * @param Capacidad the Capacidad to set
     */
    public void setCapacidad(int Capacidad) {
        this.Capacidad = Capacidad;
    }

    /**
     * @return the Siguiente
     */
    public NodoLista getSiguiente() {
        return Siguiente;
    }

    /**
     * @param Siguiente the Siguiente to set
     */
    public void setSiguiente(NodoLista Siguiente) {
        this.Siguiente = Siguiente;
    }
    
    
    
}
