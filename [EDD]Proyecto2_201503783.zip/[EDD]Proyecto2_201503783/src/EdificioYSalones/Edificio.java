/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EdificioYSalones;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author edi
 */
public class Edificio {

    NodoListaCircular Primero;
    NodoListaCircular Ultimo;

    public Edificio() {

        Primero = null;
        Ultimo = null;

    }

    public NodoListaCircular Inicio() {
        return Primero;
    }

    public Boolean EstaVacia() {
        return Primero == null && Ultimo == null;
    }

    public void insertarListaDobleCircular(String nombre) {
        NodoListaCircular Nuevo = new NodoListaCircular(nombre);
        if (EstaVacia()) {
            Primero = Ultimo = Nuevo;
            Primero.setSiguiente(Ultimo);
            Ultimo.setSiguiente(Primero);
            Primero.setAnterior(Ultimo);
            Ultimo.setAnterior(Primero);
        } else {
            Nuevo.setSiguiente(Primero);
            Primero.setAnterior(Nuevo);
            Nuevo.setAnterior(Ultimo);
            Primero = Nuevo;
            Ultimo.setSiguiente(Primero);
        }
    }

    public NodoListaCircular buscar(String Edificio) {
        NodoListaCircular actual = Primero;
        do {
                  
            if (Edificio.equals(actual.getNombreEdificio())) {
                return actual;
            }
            actual = actual.getSiguiente();
              
        } while (actual != Primero);
        return null;
    }

    public boolean existe(String Edificio) {
        boolean existe = false;
        NodoListaCircular actual = Primero;

        do {
            if (actual != null) {
                if (actual.getNombreEdificio().equals(Edificio)) {
                    existe = true;
                    break;
                }
                 actual = actual.getSiguiente();
            }
          } while (actual != Primero);
        return existe;
    }

    public int Size() {
        int contador = 0;
        NodoListaCircular actual = Primero;
        do {
            contador++;
            actual = actual.getSiguiente();
        } while (actual != Primero);
        return contador;
    }

    public void Modificar(String Edificio, String nombreEdificio) {

        NodoListaCircular actual = Primero;
        do {
            if (Edificio.equals(actual.getNombreEdificio())) {
                actual.setNombreEdificio(nombreEdificio);
                break;
            }
            actual = actual.getSiguiente();
        } while (actual != Primero);
    }

    public void Eliminiar(String nombre) {
        if (!EstaVacia()) {
            NodoListaCircular Actual = Primero;
            NodoListaCircular Anterior = null;
            while (Actual != null) {
                if (nombre.equals(Actual.getNombreEdificio())) {
                    break;
                } else {
                    Anterior = Actual;
                    Actual = Actual.getSiguiente();
                }
            }
            if (Actual != null) {
                if (Primero == Actual && Ultimo == Actual) {
                    Primero = Ultimo = null;
                    //  Primero.setSiguiente(null);
                } else if (Actual == Primero) {
                    // Primero = Primero.getSiguiente();
                    Primero = null;
                    Actual = Actual.getSiguiente();
                    Primero = Actual;
                    Primero.setAnterior(Ultimo);
                    Ultimo.setSiguiente(Primero);
                } else if (Actual == Ultimo) {
                    Anterior.setSiguiente(Primero);
                    Primero.setAnterior(Anterior);
                } else {
                    Anterior.setSiguiente(Actual.getSiguiente());
                    Actual.getSiguiente().setAnterior(Actual.getAnterior());
//   Actual.setSiguiente(null);
                }
                Actual = null;
            }
        } else {
            System.out.println("La lista esta Vacia");
        }
    }

    /*
           else if (Ultimo.getId() < id) {
            Ultimo.setSiguiente(Nuevo);
            Primero.setAnterior(Nuevo);
            Nuevo.setAnterior(Ultimo);
            Nuevo.setSiguiente(Primero);
            Ultimo = Nuevo;
          }
     */
    public String RecorrerListaCircular() {

        String Cuerpo = "";

        if (!EstaVacia()) {
            NodoListaCircular Actual = Primero;
            NodoListaCircular Anterior = null;
            do {
                //    Cuerpo += "node" + Actual.getNombreSalon() + "[label = " + "\"{<val> ant |" + Actual.getNombreSalon() + "|<ptr> sig}\"" + "];\n";
                if(Actual !=null){
                Cuerpo += "node" + Actual.getNombreEdificio() + "[label = " + "\"" + "Edificio " + "\n" + Actual.getNombreEdificio() + "\"" + ",style =" + "\"" + "rounded,filled" + "\"" + "width=1.5" + "];\n";

                if (Actual.getListaSalon() != null && Actual.getListaSalon().EstaVacio() == false && Actual.getListaSalon().Primero !=null ) {
                    Cuerpo += Actual.getListaSalon().Graficar(Actual.getNombreEdificio()) + "\n";
                    Cuerpo += "node" + Actual.getNombreEdificio() + "->" + "ndo" + Actual.getNombreEdificio() + Actual.getListaSalon().Primero.getNumerosalon() + "\n";
                }

                Actual = Actual.getSiguiente();
                }
            } while (Actual != Primero);

            Actual = Primero;
            Cuerpo += "{ rank=same;";
            do {
                Cuerpo += "node" + Actual.getNombreEdificio() + " ";
                Actual = Actual.getSiguiente();
            } while (Actual != Primero);
            Cuerpo += "}";

            Actual = Primero;

            do {
                if (Actual.getAnterior() == Primero && Actual.getSiguiente() == Primero) {
                    Cuerpo += "node" + Actual.getNombreEdificio() + "->" + "node" + Actual.getAnterior().getNombreEdificio() + ";\n";
                    Cuerpo += "node" + Actual.getNombreEdificio() + "->" + "node" + Actual.getSiguiente().getNombreEdificio() + ";\n";
                } else {

                    Cuerpo += "node" + Actual.getNombreEdificio() + "->" + "node" + Actual.getAnterior().getNombreEdificio() + ";\n";
                    Cuerpo += "node" + Actual.getNombreEdificio() + "->" + "node" + Actual.getSiguiente().getNombreEdificio() + ";\n";
                }
                Actual = Actual.getSiguiente();
            } while (Actual != Primero);

        } else {
            System.out.println("La lista Esta Vacia");
        }
        return Cuerpo;
    }

    public void GraficarListaDoblementeCircular() {
        try {
            String ruta = "listadoblementecircular.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(
                    " digraph G {\n"
                    //   + "     rankdir=LR; "
                    //   + "" + " node[ shape=record,style=filled, fontcolor=black, color=blue];  \n"
                    //   + "edge[color=chartreuse1] \n"

                    + "" + " node[ shape=record,  style=filled ,fillcolor=seashell2, fontcolor=black, color=coral1];  \n"
                    + "edge[color=chartreuse1] \n"
            );
            bw.write(this.RecorrerListaCircular() + "\n" + "}");

            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "listadoblementecircular.png", "listadoblementecircular.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "listadoblementecircular.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
