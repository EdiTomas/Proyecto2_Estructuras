/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EdificioYSalones;

/**
 *
 * @author edi
 */
public class Salon {

    NodoLista Primero;
    NodoLista Ultimo;

    public Salon() {
    
    }
 
    
    
    
    public Boolean EstaVacio() {
        return Primero == null && Ultimo == null;
    }

    public  NodoLista Inicio(){
     return Primero;
    }
    
    
    public int Size() {
        NodoLista indice;
        int contador=0;
        for (indice = Primero; indice != null; indice = indice.getSiguiente()) {
            contador++;
        }
        return contador;
    }
    
    
    public Boolean buscarLista(int NumeroSalon) {
        NodoLista indice;
        Boolean existe = false;
        for (indice = Primero; indice != null; indice = indice.getSiguiente()) {
            if (NumeroSalon == indice.getNumerosalon()) {
                existe = true;
                break;
            }
        }
        return existe;
    }

    public NodoLista Find(int NumeroSalon) {
        NodoLista indice;
        
        for (indice = Primero; indice != null; indice = indice.getSiguiente()) {
            if (NumeroSalon == indice.getNumerosalon()) {
               return indice;
            }
        }
        return null;
    }
    
    
    
    public void InsertarOrden(int NumeroSalon, int Capacidad) {

        NodoLista nuevo = new NodoLista(NumeroSalon, Capacidad);

        if (EstaVacio()) {
            nuevo.setSiguiente(null);
            Primero = Ultimo = nuevo;
        } else if (NumeroSalon < Primero.getNumerosalon()) {
            nuevo.setSiguiente(Primero);
            Primero = nuevo;

        } else {
            NodoLista anterior, p;
            anterior = p = Primero;
            while ((p.getSiguiente() != null) && (NumeroSalon > p.getNumerosalon())) {
                anterior = p;
                p = p.getSiguiente();
            }
            if (NumeroSalon > p.getNumerosalon()) {
                anterior = p;
            }
            nuevo.setSiguiente(anterior.getSiguiente());
            anterior.setSiguiente(nuevo);
        }
       
    }

    public void Modificar(int NumeroSalon,int Capacidad){
     NodoLista indice;
        for (indice = Primero; indice != null; indice = indice.getSiguiente()) {
            if (NumeroSalon == indice.getNumerosalon()) {
                  indice.setCapacidad(Capacidad);
                break;
            }
        }
    }
    
    public void Eliminar(int NumeroSalon) {

        if (!EstaVacio()) {
            NodoLista Actual = Primero;
            NodoLista Anterior = null;
            while (Actual != null) {
                if (Actual.getNumerosalon() == NumeroSalon) {
                    break;
                } else {
                    Anterior = Actual;
                    Actual = Actual.getSiguiente();
                }
            }
            if (Actual != null) {
                if (Actual == Primero) {
                    Primero = Primero.getSiguiente();

                } else {
                    Anterior.setSiguiente(Actual.getSiguiente());
                }
                Actual = null;

            }
        } else {
            System.out.println("No existe elementos en La lista");
        }
    }

    public String RecorrerLista(String id) {
        String Cuerpo = "";

        NodoLista Actual = Primero;
        while (Actual != null) {
            if (Primero == Actual) {
                Cuerpo += "ndo"+id+Primero.getNumerosalon() + "[" + "label=" + "\"" + "Salon " + Primero.getNumerosalon()+"\""  + ",style =" +"\"" +"rounded,filled"+"\"" + ",width=1.0"+  "]" + ";" + "\n";
            } else {
                Cuerpo += "ndo"+id+ Actual.getNumerosalon() + "[" + "label=" + "\"" + "Salon " + Actual.getNumerosalon()+"\"" + ",style =" +"\"" +"rounded,filled"+"\"" + ",width=1.0"+  "]" + ";" + "\n";
            }
            Actual = Actual.getSiguiente();
        }
         Actual = Primero;
        while (Actual != null) {
            if (Primero == Actual) {
                Cuerpo += "ndo"+id+ Primero.getNumerosalon() + " ";
            } else {
                Cuerpo += "->" + " " +"ndo"+ id+Actual.getNumerosalon();
             }
            Actual = Actual.getSiguiente();
        }
        return Cuerpo;
    }
  public String Graficar(String id){
      String cuerpo="";     
            // Si el archivo no existe es creado
           // cuerpo+= " subgraph cluster_"+id+"{\n" +
              cuerpo+= " subgraph "+id+"{\n" +
                  
            "" + " node[ shape=record, fontcolor=black,fillcolor=coral1, style=filled, color=black, width=0.5]  \n" + 
                 "    edge[color=chartreuse1] \n" +
                      "      " +this.RecorrerLista(id)+"\n"+"}";
   return cuerpo;
}













}
