/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EdificioYSalones;

/**
 *
 * @author edi
 */
public class NodoListaCircular {

     
     private String  NombreEdificio;
     private Salon listaSalon;
     private NodoListaCircular Siguiente;
     private NodoListaCircular Anterior; 

    public NodoListaCircular( String NombreSalon, Salon listaSalon) {
        this.NombreEdificio = NombreSalon;
        this.listaSalon = listaSalon;
       }

    public NodoListaCircular() {
      this.listaSalon = new Salon();
    }
    
    public NodoListaCircular(String NombreSalon) {
       this.setNombreEdificio(NombreSalon);
       this.listaSalon = new Salon();
    } 
    
    
    
    
    
    
    

    /**
     * @return the NombreSalon
     */
    public String getNombreEdificio() {
        return NombreEdificio;
    }

    /**
     * @param NombreSalon the NombreSalon to set
     */
    public void setNombreEdificio(String NombreSalon) {
        this.NombreEdificio = NombreSalon;
    }

    /**
     * @return the listaSalon
     */
    public Salon getListaSalon() {
        return listaSalon;
    }

    /**
     * @param listaSalon the listaSalon to set
     */
    public void setListaSalon(Salon listaSalon) {
        this.listaSalon = listaSalon;
    }

    /**
     * @return the Siguiente
     */
    public NodoListaCircular getSiguiente() {
        return Siguiente;
    }

    /**
     * @param Siguiente the Siguiente to set
     */
    public void setSiguiente(NodoListaCircular Siguiente) {
        this.Siguiente = Siguiente;
    }

    /**
     * @return the Anterior
     */
    public NodoListaCircular getAnterior() {
        return Anterior;
    }

    /**
     * @param Anterior the Anterior to set
     */
    public void setAnterior(NodoListaCircular Anterior) {
        this.Anterior = Anterior;
    }
    
         
    







    
}
