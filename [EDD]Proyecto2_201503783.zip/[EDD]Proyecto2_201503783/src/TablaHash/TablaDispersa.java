/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TablaHash;

import java.io.BufferedWriter;
import java.io.FileWriter;

/**
 *
 * @author edi
 */
public class TablaDispersa {

    private int tamaño;
    private static int[] tamanos;
    private int indiceTam;
    private int Utilizados;
    private float factorCargar;
    private float factorutil;
    private nodoHash[] vectorHash;

    public TablaDispersa() {
        tamanos = new int[]{37, 43, 47, 53, 59, 67, 73,
            79, 83, 89, 97, 103, 107, 113, 127, 137, 149, 157, 167, 179, 197, 211, 227, 239, 251, 263, 277, 293, 311, 997};
        this.indiceTam = 0;
        this.Utilizados = 0;
        this.factorutil = 55.0f;
        this.tamaño = tamanos[indiceTam];
        this.vectorHash = new nodoHash[tamaño];
        this.factorCargar = calcularFactordeCarga();

    }

    private int DobleDispersa(String id, int factor) {
        int tmp = transformarClave(id);
        return funcion1(tmp) + (factor * funcion2(tmp) % tamaño);
    }

    private int direccion(String id) {
        int tmp = transformarClave(id);
        return funcion1(tmp);
    }

    private int direccion2(String id, int factor) {
        int tmp = transformarClave(id);
        return (factor * funcion2(tmp));
    }

    private int funcion1(int clave) {
        return clave % tamaño;
    }

    private int funcion2(int clave) {
        //  return (1 + (clave % (tamaño - 1)));
        return ((clave % 7) + 1);

    }

    private int transformarClave(String id) {
        String codigo = "";
        int temporal = 0;
        int i = 0;
        while (i < id.length()) {
            codigo += id.codePointAt(i);
            i++;
        }
        if (codigo.length() > 9) {
            return reduccion(codigo);
        } else {
            return Integer.parseInt(codigo);
        }

    }

    private int reduccion(String codigo) {
        int temporal = 0;
        while (codigo.length() > 9) {
            String aux = "";
            for (int i = 0; i < codigo.length() / 2; i++) {
                aux += codigo.charAt(i);
            }
            if (aux.length() > 9) {
                temporal = reduccion(aux);
                aux = "";
            } else {
                temporal = Integer.parseInt(aux);
                aux = "";
            }

            for (int i = codigo.length() / 2; i < codigo.length(); i++) {
                aux += codigo.charAt(i);
            }

            if (aux.length() > 9) {
                temporal = reduccion(aux);
                aux = "";
            } else {
                temporal = Integer.parseInt(aux);
                aux = "";
            }
            codigo = temporal + "";
        }

        return temporal;
    }

    private float calcularFactordeCarga() {
        return (Utilizados * 100) / tamaño;
    }

    public boolean existe(String clave) {
        boolean existe = false;

        for (int i = 0; i < tamaño; i++) {
            int posicion = this.direccion(clave);
            if (vectorHash[posicion] != null) {
                if (vectorHash[posicion].clave.equals(clave)) {
                    existe = true;
                    break;
                } else {
                    posicion = this.direccion2(clave, i);
                    if (vectorHash[posicion].clave.equals(clave)) {
                        existe = true;
                        break;
                    }
                }

            }

        }
        return existe;
    }

    public void modificar(String clave, String nombre, String direccion) {
        for (int i = 0; i < tamaño; i++) {
            int posicion = this.direccion(clave);
            if (vectorHash[posicion] != null) {
                if (vectorHash[posicion].clave.equals(clave)) {
                    vectorHash[posicion].nombre = nombre;
                    vectorHash[posicion].direccion = direccion;
                  break;
                } else {

                    int nuevaposicion = this.direccion2(clave, i);
                    if (vectorHash[nuevaposicion] != null) {
                        if (vectorHash[nuevaposicion].clave.equals(clave)) {
                            vectorHash[nuevaposicion].nombre =nombre;
                            vectorHash[nuevaposicion].direccion = direccion;
                             break;
                        } 
                    } else {
                        System.out.println("No se encontro ninguna clave");
                        break;
                    }

                }// fin del else
            }  // fin del else
        }   // fin del for
    }

   public  nodoHash[] retonarvector(){
   return vectorHash;
   }      
    public int size(){
    return tamaño;
    }
    
    public void eliminar(String clave) {
   
        for (int i = 0; i < tamaño; i++) {
            int posicion = this.direccion(clave);
            if (vectorHash[posicion] != null) {
                if (vectorHash[posicion].clave.equals(clave)) {
                    vectorHash[posicion].clave = "";
                    vectorHash[posicion].nombre = "";
                    vectorHash[posicion].direccion = "";
                    vectorHash[posicion].estado = 'b';
                    Utilizados -= 1;
                    break;
                } else {

                    int nuevaposicion = this.direccion2(clave, i);
                    if (vectorHash[nuevaposicion] != null) {
                        if (vectorHash[nuevaposicion].clave.equals(clave)) {
                            vectorHash[nuevaposicion].clave = "";
                            vectorHash[nuevaposicion].nombre = "";
                            vectorHash[nuevaposicion].direccion = "";
                            vectorHash[nuevaposicion].estado = 'b';
                            Utilizados -= 1;
                            break;
                        } else {
                            System.out.println("No se encontro ninguna clave");
                            break;
                        }
                    } else {
                        System.out.println("No se encontro ninguna clave");
                        break;
                    }

                }// fin del else
            }  // fin del else
        }   // fin del for
    }

    
    
      
    public void insertar(String clave, String nombre, String direccion) {
        boolean insertado = false;
        if (factorCargar <= 55.0f) {

            for (int i = 0; i < tamaño; i++) {
                int posicion = this.direccion(clave);
                if (vectorHash[posicion] == null || vectorHash[posicion].estado == 'b') {

                    vectorHash[posicion] = new nodoHash(clave, nombre, direccion);
                    Utilizados += 1;
                    this.factorCargar = this.calcularFactordeCarga();
                    insertado = true;
                    break;

                } else {   // aqui le pongo la segundo formula para las colisiones 

                    if (vectorHash[posicion].clave.equals(clave)) {
                        System.out.println("Estudiante ya ingresado");
                        break;
                    } else {

                        int nuevaposicion = this.direccion2(clave, i);

                        if (vectorHash[nuevaposicion] != null) {
                            if (vectorHash[nuevaposicion].clave.equals(clave)) {
                                System.out.println("Estudiante ya ingresado");
                                break;
                            }
                            //  else {}
                        } else {
                            vectorHash[nuevaposicion] = new nodoHash(clave, nombre, direccion);
                            Utilizados += 1;
                            this.factorCargar = this.calcularFactordeCarga();
                            insertado = true;
                            System.out.println("Colision en la posicion" + nuevaposicion);
                            break;

                        }
                   }    // fin del else if  

                }
                /*
                if (insertado == true) {
                    System.out.println("Se ha insertado correctamente");
                } else {
                    System.out.println("No se insertado correctamente");
                }  */

            }
        } else {

            Rehash();
            this.insertar(clave, nombre, direccion);
        }

    }

    private void Rehash() {
        nodoHash[] temporal = vectorHash;
        int temporaltamaño = tamaño;
        if (indiceTam < tamanos.length) {
            indiceTam += 1;
            if (indiceTam == tamanos.length - 1) {
                System.out.println("Se alcanzo el tamaño maximo");
            }
        }
        tamaño = tamanos[indiceTam];
        vectorHash = new nodoHash[tamaño];
        Utilizados = 0;
        this.factorCargar = calcularFactordeCarga();
        for (int i = 0; i < temporaltamaño; i++) {
            if (temporal[i] != null) {
                this.insertar(temporal[i].clave, temporal[i].nombre, temporal[i].direccion);
            }
        }
        System.out.println("Rehashing realizado correctamente");
    }

    public void GraficarTablaHash() {

        try {
            String ruta = "Tablahash.dot";
            // Si el archivo no existe es creado
            FileWriter fw = new FileWriter(ruta);
            BufferedWriter bw = new BufferedWriter(fw);
            String salida = " digraph G { \n"
                    + "node [shape=plaintext]\n"
                    + "a [label=<<TABLE BORDER=\"1\" CELLBORDER=\"1\" CELLSPACING=\"1\"  bgcolor=\"coral1\"   >";
            for (int i = 0; i < tamaño; i++) {
                salida += "<TR>";
                if (vectorHash[i] == null) {
                    salida += "<TD>" + i + "</TD>" + "<TD>  </TD> \n";
                } else {
                    salida += "<TD>" + i + "</TD>" + "<TD>" + vectorHash[i].clave + "  " + vectorHash[i].nombre + "  " + vectorHash[i].direccion + "</TD> \n";
                }
                salida += "</TR>";
            }
            salida += "  \n"
                    + "</TABLE>>];"
                    // + "}"
                    + "}";
            bw.write(salida);
            bw.close();
            fw.close();

            ProcessBuilder pbuilder;
            pbuilder = new ProcessBuilder("dot", "-Tpng", "-o", "Tablahash.png", "Tablahash.dot");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();

            pbuilder = new ProcessBuilder("eog", "Tablahash.png");
            pbuilder.redirectErrorStream(true);
            //Ejecuta el proceso
            pbuilder.start();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }



   /*
        for (int i = 0; i < tamaño; i++) {
            int posicion = this.DobleDispersa(clave, i);
            if (posicion > tamaño) {
                posicion -= tamaño;
            }

            if (vectorHash[posicion] != null) {
                if (vectorHash[posicion].clave.equals(clave)) {
                    vectorHash[posicion].clave = "";
                    vectorHash[posicion].direccion = "";
                    vectorHash[posicion].nombre = "";
                    vectorHash[posicion].estado = 'b';
                    break;
                }
            }

        }
         */

        /*
        for (int i = 0; i < tamaño; i++) {
            int posicion = this.DobleDispersa(clave, i);
            if (posicion > tamaño) {
                posicion -= tamaño;
            }
            if (vectorHash[posicion] != null) {
                if (vectorHash[posicion].clave.equals(clave)) {
                    vectorHash[posicion].nombre = nombre;
                    vectorHash[posicion].direccion = direccion;
                    break;
                }
            }
        }
         */
    
    
    
    
    /*   va en la insercion
    
            for (int i = 0; i < tamaño; i++) {
                
                
                int posicion = this.DobleDispersa(clave, i);
                if (posicion > tamaño) {
                    posicion -= tamaño;
                }
                if (vectorHash[posicion] == null || vectorHash[posicion].estado == 'b') {
                    vectorHash[posicion] = new nodoHash(clave, nombre, direccion);
                    Utilizados += 1;
                    this.factorCargar = this.calcularFactordeCarga();
                    insertado = true;
                    break;
                } else {
                    
                    if (vectorHash[posicion].clave.equals(clave)) {
                        System.out.println("La variable ya existe");
                        break;
                    } else {
                        System.out.println("Colision en la posicion" + posicion);
                    }

                }
            }// termina el for
     */








}
